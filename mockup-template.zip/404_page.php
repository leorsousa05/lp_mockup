<!DOCTYPE html>
<html lang="pt-br">
<meta http-equiv="refresh" content="3; URL=/">
<?php include 'includes/configurations/head.php'; ?>
<body class="error-page">
    
    <h1>Erro 404</h1>
    <p>Estaremos te redirecionando!</p>

</body>
</html>
