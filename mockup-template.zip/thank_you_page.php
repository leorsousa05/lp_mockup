<!DOCTYPE html>
<html lang="pt-br">
<meta http-equiv="refresh" content="3; URL=/">
<?php include 'includes/configurations/head.php'; ?>
<body class="thank-you-page">
    
    <h1>Agradecemos o Contato</h1>
    <p>Muito obrigado por entrar em contato, estaremos te redirecionando.</p>

</body>
</html>
