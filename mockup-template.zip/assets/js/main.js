const burgerMenuMobile = document.querySelector(".burger-menu");
const headerContainer = document.querySelector(".header-container");

burgerMenuMobile.addEventListener("click", () => {
    headerContainer.classList.toggle("show")   
});
