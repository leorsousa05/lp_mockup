<!DOCTYPE html>
<html lang="pt-br">
<?php include 'includes/configurations/head.php'; ?>
<body>
    <?php include 'includes/components/header.php' ?> 
    <main>
        Home
    </main>
    <?php include 'includes/components/footer.php' ?>
    <?php include 'includes/configurations/schema_data.php' ?>

    <script src="assets/js/main.js"></script>
</body>
</html>
