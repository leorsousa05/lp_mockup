<header>

    <div class="header-container">
        <h1 class="logo">Ooe</h1>

        <div class="burger-menu">
            <div class="lines"></div>
            <div class="lines"></div>
            <div class="lines"></div>
        </div>

        <nav>
            <ul>
                <li>Home</li>
                <li>About</li>
                <li>Contatos</li>
            </ul> 
        </nav>

    </div>


</header>
